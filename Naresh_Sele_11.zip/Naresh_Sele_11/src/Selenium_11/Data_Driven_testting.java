package Selenium_11;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Data_Driven_testting {

	public static void main(String[] args) throws IOException {
		//locate the Excel file
		FileInputStream file=new FileInputStream("C:\\Users\\DELL\\Desktop\\Naresh_IT.xlsx");
		//need to create workbook object
		XSSFWorkbook wb=new XSSFWorkbook(file);//100
		//need to read the sheet
		//HSSFWorkbook.xls
		XSSFSheet sheet=wb.getSheet("Sheet1");
		//read the sheet throught index
	//	XSSFSheet sheet=wb.getSheetAt(0);
		int rowcount=sheet.getLastRowNum();
		System.out.println("The number of rows is:"+rowcount);
		int column=sheet.getRow(0).getLastCellNum();
		System.out.println("The number of column is:"+column);
		//thi is for ROW's
		for(int i=0;i<rowcount;i++)
		{
			//outerloop====>get the Rows
			//inner loop--->get the columns
			XSSFRow count=sheet.getRow(i);
			//This is for column
			for(int j=0;j<column;j++)
			{
				String data=count.getCell(j).toString();
				System.out.print("     |    "+data);
			}
			System.out.println();
		}
		
		
		

	}

}
