package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp10 {
	WebDriver driver;
	public void LaunchAUT()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\chromedriver_win32 (18)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://login.salesforce.com/?locale=in");
		driver.manage().window().maximize();
	}
	public void Login_Salesforce() throws InterruptedException
	{
		driver.findElement(By.id("username")).sendKeys("anilkumartesting22@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("kumartesting");
		Thread.sleep(2000);
		driver.findElement(By.id("Login")).click();
	}

	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp10 obj=new SadbasicsExp10();
		obj.LaunchAUT();
		obj.Login_Salesforce();

	}

}
