package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp11 {
	WebDriver driver;
	public void LaunchAUT()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\chromedriver_win32 (18)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://login.salesforce.com/?locale=in");
		driver.manage().window().maximize();
	}
	public void Sendata(String username,String password) throws InterruptedException
	{
		driver.findElement(By.id("username")).sendKeys(username);
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys(password);
		Thread.sleep(2000);
		driver.findElement(By.id("Login")).click();
	}

	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp11 obj=new SadbasicsExp11();
		obj.LaunchAUT();
		obj.Sendata("anilkumare@gmail.com", "sjdbkjsbv");
		obj.Sendata("aniret346@gmil.com", "sdbisbv");
		obj.Sendata("1234hvmnlbkn@gmail.com", "sksuvb");
	}

}
