package Selenium_11;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class SadbasicsExp12 {
	WebDriver driver;
	public void LaunchAUT() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://login.salesforce.com/");
		Thread.sleep(2000);
		driver.manage().window().maximize();
	}
	public void Senddata() throws InterruptedException
	{
		driver.findElement(By.id("username")).sendKeys("anilkumartestin22@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Anil3214");
		Thread.sleep(2000);
		driver.findElement(By.id("Login")).click();
	}
	public void Get_ScreenShot() throws IOException
	{
		String we=driver.getPageSource();
		System.out.println("The page SRC is:"+we);
		if(we.contains("The username and PW!"))
		{
			System.out.println("The msg was match");
		}
		else
		{
			File src=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			File des=new File("C:\\Users\\DELL\\Desktop\\anil.jpg");
			FileHandler.copy(src, des);
		}
	}

	public static void main(String[] args) throws InterruptedException, IOException {
		SadbasicsExp12 obj=new SadbasicsExp12();
		obj.LaunchAUT();
		obj.Senddata();
		obj.Get_ScreenShot();

	}

}
