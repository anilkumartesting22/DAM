package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SadbasicsExp15 {
	WebDriver driver;
	public void LaunchAUT() throws InterruptedException
	{
		String[] browser= {"chrome","firefox"};
		for(String browsers:browser)
		{
			if(browsers.equalsIgnoreCase("chrome"))
			{
				System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
				driver=new ChromeDriver();
				driver.get("https://www.amazon.in/");
				driver.manage().window().maximize();
				Thread.sleep(2000);
				driver.findElement(By.id("twotabsearchtextbox")).sendKeys("I phone");
				Thread.sleep(3000);
				driver.findElement(By.id("nav-search-submit-text")).click();
				Thread.sleep(3000);
				
				}
			else if(browsers.equalsIgnoreCase("firefox"))
			{
				System.setProperty("webdriver.gecko.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\geckodriver-v0.31.0-win64 (1)\\geckodriver.exe");
				driver=new FirefoxDriver();
				driver.get("https://www.amazon.in/");
				driver.manage().window().maximize();
				Thread.sleep(2000);
				driver.findElement(By.id("twotabsearchtextbox")).sendKeys("I phone");
				Thread.sleep(3000);
				driver.findElement(By.id("nav-search-submit-text")).click();
				Thread.sleep(3000);
			}
			else
			{
				System.out.println("The browser not");
			}
		}
	}

	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp15 obj=new SadbasicsExp15();
		obj.LaunchAUT();

	}

}
