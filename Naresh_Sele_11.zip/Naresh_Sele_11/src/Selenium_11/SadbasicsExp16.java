package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class SadbasicsExp16 {
	WebDriver driver;
	String browser="Chrome";
	String browser1="Edge";
	public void LaunchAUT() throws InterruptedException
	{
		SadbasicsExp16 obj=new SadbasicsExp16();
		if(obj.browser.equalsIgnoreCase("chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.get("https://www.amazon.in/");
			driver.manage().window().maximize();
			Thread.sleep(2000);
			driver.findElement(By.id("twotabsearchtextbox")).sendKeys("I phone");
			Thread.sleep(3000);
			driver.findElement(By.id("nav-search-submit-text")).click();
			Thread.sleep(3000);
		}
		if(obj.browser1.equalsIgnoreCase("Edge"))
		{
			System.setProperty("webdriver.edge.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\edgedriver_win64\\msedgedriver.exe");
			driver=new EdgeDriver();
			driver.get("https://www.amazon.in/");
			driver.manage().window().maximize();
			Thread.sleep(2000);
			driver.findElement(By.id("twotabsearchtextbox")).sendKeys("I phone");
			Thread.sleep(3000);
			driver.findElement(By.id("nav-search-submit-text")).click();
			Thread.sleep(3000);
		}
	}

	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp16 obj=new SadbasicsExp16();
		obj.LaunchAUT();

	}

}
