package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SadbasicsExp18 {
	WebDriver driver;
	public void LaunchAUT() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.salesforce.com/in/form/signup/freetrial-sales/?d=jumbo1-btn-ft");
		Thread.sleep(2000);
		driver.manage().window().maximize();
	}
	public void Senddata() throws InterruptedException
	{
		driver.findElement(By.name("UserFirstName")).sendKeys("Anil");
		Thread.sleep(2000);
		driver.findElement(By.name("UserLastName")).sendKeys("kumar");
		Thread.sleep(2000);
		driver.findElement(By.name("UserEmail")).sendKeys("anilkumartesting22@gmail.com");
		Thread.sleep(2000);
		WebElement job_title=driver.findElement(By.name("UserTitle"));
		//create Select method
		Select slcobj=new Select(job_title);
		slcobj.selectByValue("Sales_Manager_AP");
		Thread.sleep(2000);
		slcobj.selectByIndex(3);
		Thread.sleep(3000);
		
	}
	public void Company_name() throws InterruptedException
	{
		driver.findElement(By.name("CompanyName")).sendKeys("NTT");
		Thread.sleep(2000);
		WebElement Employee=driver.findElement(By.name("CompanyEmployees"));
		Select slcobj1=new Select(Employee);
		slcobj1.selectByIndex(4);
		Thread.sleep(2000);
		slcobj1.selectByVisibleText("1 - 15 employees");
		Thread.sleep(2000);
		driver.findElement(By.name("UserPhone")).sendKeys("9876534123");
		Thread.sleep(2000);
		
	}
	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp18 obj=new SadbasicsExp18();
		obj.LaunchAUT();
		obj.Senddata();
		obj.Company_name();

	}

}
