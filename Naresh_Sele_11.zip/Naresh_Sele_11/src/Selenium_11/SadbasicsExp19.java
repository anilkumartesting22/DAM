package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp19 {
	WebDriver driver;
	public void LaunchAUT() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.indiehackers.com/sign-in");
		Thread.sleep(2000);
		driver.manage().window().maximize();
	}
	public void Click_On_OK() throws InterruptedException
	{
		driver.findElement(By.linkText("Reset")).click();
		Thread.sleep(1000);
		//need to use alerts
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	public void Click_On_Cancel() throws InterruptedException
	{
		driver.findElement(By.linkText("Reset")).click();
		Thread.sleep(1000);
		driver.switchTo().alert().dismiss();
		Thread.sleep(2000);
	}
	public void Sendata_in_Alert() throws InterruptedException
	{
		driver.findElement(By.linkText("Reset")).click();
		Thread.sleep(1000);
		driver.switchTo().alert().sendKeys("anilkumartesting22@gmail.com");
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}
	public void Get_Text_In_Alert() throws InterruptedException
	{
		driver.findElement(By.linkText("Reset")).click();
		Thread.sleep(2000);
		String text=driver.switchTo().alert().getText();
		System.out.println("The alert text is:"+text);
	}
	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp19 obj=new SadbasicsExp19();
		obj.LaunchAUT();
		obj.Click_On_OK();
		obj.Click_On_Cancel();
		obj.Sendata_in_Alert();
		obj.Get_Text_In_Alert();

	}

}
