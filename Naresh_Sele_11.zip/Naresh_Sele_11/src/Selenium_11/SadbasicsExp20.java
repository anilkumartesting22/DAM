package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp20 {
	WebDriver driver;
	public void LaunchAUT() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.facebook.com/");
		Thread.sleep(2000);
		driver.manage().window().maximize();
	}
	public void Sendata() throws InterruptedException
	{
		driver.findElement(By.cssSelector("#email")).sendKeys("Ajit");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("[type='password']")).sendKeys("Subbu");
		Thread.sleep(1000);
		driver.findElement(By.cssSelector("[name='login']")).click();
	}

	public static void main(String[] args) throws InterruptedException {
	SadbasicsExp20 obj=new SadbasicsExp20();
	obj.LaunchAUT();
	obj.Sendata();

	}

}
