package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SadbasicsExp22 {
		WebDriver driver;
		Actions actobj;
		public void LaunchAUT() throws InterruptedException
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\chromedriver_win32 (18)\\chromedriver.exe");
			driver=new ChromeDriver();
			driver.get("https://www.w3schools.com/jsref/tryit.asp?filename=tryjsref_ondblclick");
			Thread.sleep(2000);
			driver.manage().window().maximize();
			
		}
	   public void Handle_the_frame()
	   {
		   driver.switchTo().frame("iframeResult");
		   actobj=new Actions(driver);
		   WebElement double1=driver.findElement(By.xpath("//p[text()='Double-click this paragraph to trigger a function.']"));
		  actobj.doubleClick(double1).perform();
	   }
	   public void frame_text()
	   {
		   String text1=driver.findElement(By.xpath("//p[text()='Hello World ']")).getText();
		   System.out.println("The double click text is:"+text1);
	   }

	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp22 obj=new SadbasicsExp22();
		obj.LaunchAUT();
		obj.Handle_the_frame();
		obj.frame_text();

	}

}
