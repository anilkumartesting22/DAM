package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SadbasicsExp23 {
	WebDriver driver;
	Actions actobj;
  public void LaunchAut() throws InterruptedException
  {
	  System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
	  driver=new ChromeDriver();
	  driver.get("https://jqueryui.com/droppable/");
	  Thread.sleep(2000);
	  driver.manage().window().maximize();
  }
  public void frame_count()
  {
	  int count=driver.findElements(By.tagName("iframe")).size();
	  System.out.println(count);
  }
  public void Drag_And_Drop()
  {
	  driver.switchTo().frame(0);
	  actobj=new Actions(driver);
	  WebElement drg=driver.findElement(By.id("draggable"));
	  WebElement drop=driver.findElement(By.id("droppable"));
	  actobj.dragAndDrop(drg, drop).perform();
	  
  }
	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp23 obj=new SadbasicsExp23();
		obj.LaunchAut();
		obj.frame_count();
		obj.Drag_And_Drop();

	}
	

}
