package Selenium_11;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class SadbasicsExp26 {
 WebDriver driver;
 Actions actobj;
 public void LaunchAUT() throws InterruptedException
 {
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\chromedriver_win32 (18)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_select_multiple");
		Thread.sleep(2000);
		driver.manage().window().maximize();
 }
 public void MultiSelector() throws InterruptedException
 {
	 driver.switchTo().frame("iframeResult");
	 WebElement drop=driver.findElement(By.id("cars"));
	 Thread.sleep(2000);
	 Select slcobj=new Select(drop);
	 if(slcobj.isMultiple())
	 {
		 slcobj.selectByVisibleText("Audi");
		 Thread.sleep(2000);
		 slcobj.selectByValue("volvo");
		 Thread.sleep(2000);
		 List<WebElement>alloption=slcobj.getAllSelectedOptions();
		 for(int i=0;i<alloption.size();i++)
{
			String data= alloption.get(i).getText();
			System.out.println("The selected options is: "+data);
}
		 Thread.sleep(2000);
		 slcobj.deselectByVisibleText("Audi");
		 slcobj.deselectAll();
	 }
	 else
	 {
		 System.out.println("This is not multiselector");
	 }
	 driver.switchTo().defaultContent();
	 Thread.sleep(2000);
	 
	 
 }
	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp26 obj=new SadbasicsExp26();
		obj.LaunchAUT();
		obj.MultiSelector();

	}

}
