package Selenium_11;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class SadbasicsExp27 {
	WebDriver driver;
	Actions actobj;
	public void LaunchAUT() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\chromedriver_win32 (18)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		
	}
	public void SelectedOption() throws InterruptedException
	{
		actobj=new Actions(driver);
		WebElement search=driver.findElement(By.id("twotabsearchtextbox"));
		actobj.sendKeys(search,"Selenium").perform();
//		actobj.sendKeys(Keys.DOWN).perform();
//		actobj.sendKeys(Keys.DOWN).perform();
//		actobj.sendKeys(Keys.DOWN).perform();
//		actobj.sendKeys(Keys.DOWN).perform();
//		actobj.sendKeys(Keys.DOWN).perform();
//		actobj.sendKeys(Keys.DOWN).perform();
		for(int i=0;i<=6;i++)
		{
			actobj.sendKeys(Keys.DOWN).perform();
			Thread.sleep(2000);
		}
		actobj.sendKeys(Keys.ENTER).perform();
		Thread.sleep(2000);
	}

	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp27 obj=new SadbasicsExp27();
		obj.LaunchAUT();
		obj.SelectedOption();

	}

}
