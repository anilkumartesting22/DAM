package Selenium_11;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SadbasicsExp3 {
	public void LaunchAUT() 
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\geckodriver-v0.31.0-win64 (1)\\geckodriver.exe");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://login.salesforce.com/?locale=in");
		
		driver.manage().window().maximize();
	}

	public static void main(String[] args)  {
		SadbasicsExp3 obj=new SadbasicsExp3();
		obj.LaunchAUT();

	}

}
