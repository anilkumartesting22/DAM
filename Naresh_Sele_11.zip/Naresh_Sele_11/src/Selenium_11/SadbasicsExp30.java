package Selenium_11;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp30 {
	WebDriver driver;
    JavascriptExecutor jse;
    public void Click() throws InterruptedException
    {
    	JavascriptExecutor jse=(JavascriptExecutor)driver;
    	WebElement Loi=driver.findElement(By.id("Login"));
    	jse.executeScript("arguments[0].click();",Loi);
    	Thread.sleep(2000);
    }
    public void Uname() throws InterruptedException
    {
    	JavascriptExecutor jse=(JavascriptExecutor)driver;
    	WebElement username=driver.findElement(By.id("username"));
    	jse.executeScript("arguments[0].value='anilkumartesting22@gmail.com';", username);
    	Thread.sleep(2000);
    }
    public void LaunchAUT()
    {
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
    	driver=new ChromeDriver();
    	driver.get("https://login.salesforce.com/?locale=in");
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	driver.manage().window().maximize();
    }
    
    public void Password() throws InterruptedException
    {
    	JavascriptExecutor jse=(JavascriptExecutor)driver;
    	WebElement Pname=driver.findElement(By.id("password"));
    	jse.executeScript("arguments[0].value='Aniouyr';", Pname);
    	Thread.sleep(2000);
    }
    public void Helight() throws InterruptedException
    {
    	JavascriptExecutor jse=(JavascriptExecutor)driver;
    	WebElement He=driver.findElement(By.id("password"));
    	jse.executeScript("arguments[0].style='border:5px dotted green';", He);
    	Thread.sleep(2000);
    }
    
	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp30 obj=new SadbasicsExp30();
		obj.LaunchAUT();
		obj.Uname();
		obj.Password();
		obj.Click();
		obj.Helight();

	}

}
