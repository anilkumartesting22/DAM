package Selenium_11;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp31 {
	WebDriver driver;
	JavascriptExecutor jse;
	public void LaunchAUT()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (22)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	public void ScrollingTopto_B() throws InterruptedException
	{
		jse=(JavascriptExecutor)driver;
		jse.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(3000);
	    jse.executeScript("window.scrollTo(document.body.scrollHeight,0)");
	    Thread.sleep(3000);
	}
	public void Click_Expected_Element() throws InterruptedException
	{
		jse=(JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,800);");
		Thread.sleep(4000);
		WebElement flight=driver.findElement(By.xpath("//span[text()='Get up to ₹2000 off on flights']"));
		flight.click();
	}

	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp31 obj=new SadbasicsExp31();
		obj.LaunchAUT();
	//	obj.ScrollingTopto_B();
	//	obj.Bottom_to_Top();
		obj.Click_Expected_Element();
	}

}
