package Selenium_11;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp32 {
	WebDriver driver;
	JavascriptExecutor jse;
	public void LaunchAUT() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (21)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	public void GetTitle() throws InterruptedException
	{
		jse=(JavascriptExecutor)driver;
		String title=jse.executeScript("return document.title").toString();
		Thread.sleep(3000);
		System.out.println(title);
	}
	public void Refresh() throws InterruptedException
	{
		jse=(JavascriptExecutor)driver;
		jse.executeScript("history.go(0);");
		Thread.sleep(3000);
	}
	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp32 obj=new SadbasicsExp32();
		obj.LaunchAUT();
		obj.GetTitle();
		obj.Refresh();

	}

}
