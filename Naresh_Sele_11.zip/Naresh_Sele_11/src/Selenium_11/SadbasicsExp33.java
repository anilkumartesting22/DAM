package Selenium_11;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp33 {
	WebDriver driver;
	JavascriptExecutor jse;
 public void LaunchAUT()
 {
	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (22)\\chromedriver.exe");
	 driver=new ChromeDriver();
	 driver.get("https://login.salesforce.com/?locale=in");
	 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	 driver.manage().window().maximize();
 }
 public void Get_PageSRC() throws InterruptedException
 {
	 jse=(JavascriptExecutor)driver;
	 String pageSRC=jse.executeScript("return document.documentElement.innerText;").toString();
	 Thread.sleep(2000);
	 System.out.println(pageSRC);
 }
 public void CustomAlert() throws InterruptedException
 {
	 jse=(JavascriptExecutor)driver;
	 jse.executeScript("alert('WelCome to salesforce Mr.Anil');");
	 Thread.sleep(2000);
	
 }
 	public static void main(String[] args) throws InterruptedException {
 		SadbasicsExp33 obj=new SadbasicsExp33();
 		obj.LaunchAUT();
 		obj.Get_PageSRC();
 		obj.CustomAlert();
	}

}
