package Selenium_11;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp5 {
	WebDriver driver;
	public void LaunchAUT() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\chromedriver_win32 (18)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://login.salesforce.com/?locale=in");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		
	}
    public void Get_URL()
    {
    	String url=driver.getCurrentUrl();
    	System.out.println("the Application URL is :"+url);
    	
    }
    public void GetSRC()
    {
    	String src=driver.getPageSource();
    	System.out.println("The sorce code is:"+src);
    	if(src.contains("label usernamelabel"))
    	{
    		System.out.println("Test pass");
    	}
    	else
    	{
    		System.out.println("test fail");
    	}
    	
    	
    }
	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp5 obj=new SadbasicsExp5();
		obj.LaunchAUT();
		obj.Get_URL();
		obj.GetSRC();

	}

}
