package Selenium_11;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp8 {
	public void LaunchAUT() throws InterruptedException
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter your expected time");
		int count=sc.nextInt();
		for(int i=1;i<=count;i++)
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\chromedriver_win32 (18)\\chromedriver.exe");
			WebDriver driver=new ChromeDriver();
			driver.get("https://www.salesforce.com/in/");
			Thread.sleep(2000);
			driver.manage().window().maximize();
			
		}
	}

	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp8 obj=new SadbasicsExp8();
		obj.LaunchAUT();
	}

}
