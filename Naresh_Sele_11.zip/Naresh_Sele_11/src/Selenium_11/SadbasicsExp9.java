package Selenium_11;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp9 {
	WebDriver driver;
	public void LaunchAUT() throws InterruptedException
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Please enter the application URL");
		String url=sc.nextLine();
		System.out.println("please enetr the application title");
		String exp_title=sc.nextLine();
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Desktop\\Selenium\\chromedriver_win32 (18)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(url);
		Thread.sleep(2000);
		driver.manage().window().maximize();
		String act_title=driver.getTitle();
		System.out.println(act_title);
		if(exp_title.equalsIgnoreCase(act_title))
		{
			System.out.println("Pass");
		}
		else
		{
			System.out.println("fail");
		}
		
	}
	public static void main(String[] args) throws InterruptedException {
		SadbasicsExp9 obj=new SadbasicsExp9();
		obj.LaunchAUT();

	}

}
