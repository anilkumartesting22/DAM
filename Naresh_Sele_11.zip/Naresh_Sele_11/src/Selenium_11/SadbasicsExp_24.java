package Selenium_11;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SadbasicsExp_24 {
	WebDriver driver;
	public void LaunchAUT()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\DELL\\Downloads\\chromedriver_win32 (22)\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.nopcommerce.com/en/demo");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	public void Handle_multiwindow() throws InterruptedException
	{
		String P_window=driver.getWindowHandle();
		driver.findElement(By.xpath("//span[text()='Admin area']")).click();
		Set<String>allwindow=driver.getWindowHandles();
		for(String handle:allwindow)
		{
			if(!handle.equals(P_window))
			{
				driver.switchTo().window(handle);
				driver.findElement(By.id("Email")).clear();
				Thread.sleep(2000);
				driver.findElement(By.id("Email")).sendKeys("admin@yourstore.com");
				Thread.sleep(2000);
				driver.findElement(By.id("Password")).clear();
				Thread.sleep(2000);
				driver.findElement(By.id("Password")).sendKeys("admin");
				Thread.sleep(2000);
				driver.findElement(By.xpath("//button[text()='Log in']")).click();
				
			}
		}
	}
	public void  CloseAUT()
	{
		driver.quit();
	}
		
	public static void main(String[]args) throws InterruptedException {	
		SadbasicsExp_24 obj=new SadbasicsExp_24();
		obj.LaunchAUT();
		obj.Handle_multiwindow();
		obj.CloseAUT();
		
	}
}